import mymodule
import simple_math

mymodule.greeting("karthick")
print (simple_math.add(1,2))